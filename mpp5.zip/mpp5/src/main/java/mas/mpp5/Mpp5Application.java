package mas.mpp5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mpp5Application {

    public static void main(String[] args) {
        SpringApplication.run(Mpp5Application.class, args);
    }

}
