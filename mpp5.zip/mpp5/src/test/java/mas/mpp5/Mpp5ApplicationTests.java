package mas.mpp5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mpp5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
