package Overlapping;

public enum PersonType {
    PERSON, SUPERVISOR, FLAT_OWNER
}
