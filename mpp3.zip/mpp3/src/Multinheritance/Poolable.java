package Multinheritance;

public interface Poolable {
    double getPoolSize();
    void setPoolSize(double size);
}
